package com.raylan.owerotmx

import com.raylan.owerotmx.model.FpsMode
import com.raylan.owerotmx.shizuku.ShizukuExecutor
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class OwerOtmxUnitTest {

  @Test
  fun `security guard expected constants match official identity`() {
    assertEquals("com.raylan.owerotmx", SecurityGuard.EXPECTED_PACKAGE)
    assertEquals("Ower OTMX", SecurityGuard.EXPECTED_APP_NAME)
    assertEquals("com.raylan.owerotmx", BuildConfig.APPLICATION_ID)
  }

  @Test
  fun `fps 120 commands and roblox fastflags match specification`() {
    val commands = ShizukuExecutor.buildFpsCommands("com.roblox.client", FpsMode.FPS_120)
    assertTrue(commands.contains("cmd game mode performance com.roblox.client"))
    assertTrue(commands.contains("cmd game set --fps 120 com.roblox.client"))
    assertTrue(commands.contains("settings put system peak_refresh_rate 120.0"))
    assertTrue(commands.contains("settings put system min_refresh_rate 120.0"))
    assertTrue(commands.contains("setprop debug.hwui.fps_divisor 1"))
    assertFalse(commands.contains("cmd thermalservice override-status 0"))

    val json = ShizukuExecutor.buildRobloxFastFlagsJson(FpsMode.FPS_120)
    assertEquals("""{"DFIntTaskSchedulerTargetFps": 120}""", json)
  }

  @Test
  fun `vip 400 commands and roblox fastflags match specification`() {
    val commands = ShizukuExecutor.buildFpsCommands("com.roblox.client", FpsMode.VIP_400)
    assertTrue(commands.contains("cmd game mode performance com.roblox.client"))
    assertTrue(commands.contains("cmd game set --fps 400 com.roblox.client"))
    assertTrue(commands.contains("settings put system peak_refresh_rate 400.0"))
    assertTrue(commands.contains("settings put system min_refresh_rate 400.0"))
    assertTrue(commands.contains("setprop debug.hwui.fps_divisor 1"))
    assertTrue(commands.contains("cmd thermalservice override-status 0"))
    assertTrue(commands.contains("cmd activity kill-all"))
    assertTrue(commands.contains("settings put global window_animation_scale 0.0"))
    assertTrue(commands.contains("settings put global transition_animation_scale 0.0"))
    assertTrue(commands.contains("settings put global animator_duration_scale 0.0"))
    assertTrue(commands.contains("setprop debug.egl.hw 1"))
    assertTrue(commands.contains("setprop debug.sf.hw 1"))

    val json = ShizukuExecutor.buildRobloxFastFlagsJson(FpsMode.VIP_400)
    assertEquals(
      """{"DFIntTaskSchedulerTargetFps": 400, "FFlagDebugForceFutureIsBrightPhase3": false, "DFIntTextureQualityOverride": 1, "FFlagDisablePostFx": true}""",
      json,
    )
  }
}
