package com.raylan.owerotmx

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.GppBad
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.raylan.owerotmx.ui.theme.NeonRed
import com.raylan.owerotmx.ui.theme.NeonRedDark
import com.raylan.owerotmx.ui.theme.TamperAlertBg

object SecurityGuard {
  const val EXPECTED_PACKAGE = "com.raylan.owerotmx"
  const val EXPECTED_APP_NAME = "Ower OTMX"

  fun isAppIntact(context: Context): Boolean {
    return runCatching {
      val actualPackage = context.packageName
      val buildPackage = BuildConfig.APPLICATION_ID
      val resName = context.getString(R.string.app_name)
      val appLabel = context.applicationInfo.loadLabel(context.packageManager).toString()

      actualPackage == EXPECTED_PACKAGE &&
        buildPackage == EXPECTED_PACKAGE &&
        resName == EXPECTED_APP_NAME &&
        appLabel == EXPECTED_APP_NAME
    }.getOrDefault(false)
  }
}

@Composable
fun SecurityTamperScreen() {
  val context = LocalContext.current

  BackHandler(enabled = true) {}

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(
        Brush.verticalGradient(
          colors = listOf(TamperAlertBg, NeonRedDark, Color(0xFF3A000A))
        )
      )
      .safeDrawingPadding()
      .padding(24.dp),
    contentAlignment = Alignment.Center,
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(20.dp))
        .background(Color(0xCC180206))
        .border(2.dp, NeonRed, RoundedCornerShape(20.dp))
        .padding(24.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      Box(
        modifier = Modifier
          .size(72.dp)
          .clip(CircleShape)
          .background(NeonRed.copy(alpha = 0.25f))
          .border(2.dp, NeonRed, CircleShape),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Filled.GppBad,
          contentDescription = stringResource(R.string.security_tamper_title),
          tint = Color.White,
          modifier = Modifier.size(40.dp),
        )
      }

      Text(
        text = stringResource(R.string.security_tamper_title),
        style = MaterialTheme.typography.headlineMedium,
        color = Color.White,
        textAlign = TextAlign.Center,
        fontWeight = FontWeight.Black,
      )

      Text(
        text = stringResource(R.string.security_tamper_body),
        style = MaterialTheme.typography.bodyLarge,
        color = Color(0xFFFFD6DC),
        textAlign = TextAlign.Center,
      )

      Text(
        text = "PKG: ${context.packageName}",
        fontFamily = FontFamily.Monospace,
        fontSize = 12.sp,
        color = Color(0xFFFF8A9B),
        textAlign = TextAlign.Center,
      )

      Spacer(modifier = Modifier.height(8.dp))

      Button(
        onClick = {
          runCatching {
            val uninstallIntent = Intent(
              Intent.ACTION_DELETE,
              Uri.parse("package:${context.packageName}"),
            ).apply {
              addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(uninstallIntent)
          }
        },
        modifier = Modifier
          .fillMaxWidth()
          .height(56.dp)
          .testTag("security_uninstall_button"),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
          containerColor = NeonRed,
          contentColor = Color.White,
        ),
      ) {
        Icon(
          imageVector = Icons.Filled.DeleteForever,
          contentDescription = null,
          modifier = Modifier.padding(end = 8.dp),
        )
        Text(
          text = stringResource(R.string.uninstall_now),
          fontWeight = FontWeight.ExtraBold,
          letterSpacing = 1.sp,
        )
      }
    }
  }
}
