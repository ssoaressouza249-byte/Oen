package com.raylan.owerotmx.model

import androidx.compose.ui.graphics.ImageBitmap

enum class FpsMode(
  val fpsValue: Int,
  val title: String,
  val subtitle: String,
  val isVip: Boolean,
) {
  FPS_120(
    fpsValue = 120,
    title = "Cravar em 120 FPS",
    subtitle = "Estabilidade competitiva",
    isVip = false,
  ),
  FPS_220(
    fpsValue = 220,
    title = "Cravar em 220 FPS",
    subtitle = "Desbloqueio extremo",
    isVip = false,
  ),
  FPS_300(
    fpsValue = 300,
    title = "Cravar em 300 FPS",
    subtitle = "Sem limitador de quadros",
    isVip = false,
  ),
  VIP_400(
    fpsValue = 400,
    title = "FUNÇÃO VIP: MODO MÁXIMO (350–400 FPS)",
    subtitle = "Libera o máximo de CPU, GPU, RAM e FastFlags",
    isVip = true,
  ),
}

enum class ShizukuStatus {
  CONNECTED,
  PERMISSION_NEEDED,
  DISCONNECTED,
}

enum class LogLevel {
  SYS,
  CMD,
  OK,
  WARN,
  ERR,
  VIP,
  FLAG,
}

data class TerminalLogEntry(
  val id: Long,
  val timestamp: String,
  val level: LogLevel,
  val message: String,
)

data class InstalledAppInfo(
  val appName: String,
  val packageName: String,
  val icon: ImageBitmap?,
  val isRoblox: Boolean,
)
