package com.raylan.owerotmx.ui.theme

import androidx.compose.ui.graphics.Color

val BgDeepBlack = Color(0xFF0A0A0E)
val CardSurface = Color(0xFF14141C)
val CardSurfaceElevated = Color(0xFF1B1B26)
val CardBorderSubtle = Color(0xFF282838)

val NeonRed = Color(0xFFFF1744)
val NeonRedDark = Color(0xFFB71C1C)
val NeonRedSoft = Color(0x29FF1744)

val VipGold = Color(0xFFFFD700)
val VipGoldDark = Color(0xFFC79100)
val VipGoldSoft = Color(0x26FFD700)

val TerminalGreen = Color(0xFF00E676)
val TerminalBg = Color(0xFF07070A)

val TextPrimary = Color(0xFFF5F5FA)
val TextSecondary = Color(0xFFA0A0B4)
val TextMuted = Color(0xFF6B6B80)

val StatusAmber = Color(0xFFFFAB00)
val TamperAlertBg = Color(0xFF8E001A)
